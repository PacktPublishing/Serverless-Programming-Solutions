const assert = require('assert')
const createTables = require('../service/model').createTables
const Product = require('../service/model').Product

process.on('unhandledRejection', e => { throw e; });


describe('Product', function() {

    this.timeout(10000);

    before(done => { 
        createTables(err => {
            if (err) console.error('\tUnable to create tables...')
            else  console.log('\tTables created...')
            done()
        });
    });

    describe('#create()', () => {
        it('should create a Product', done => {
            Product.create({ProductID: 'black_tshirt', description: 'An elegant black t-shirt', price: 10}, (err, data) => {
            if (err) throw err
            done()
            }) 
        });

        it('should create another Product', done => {
            Product.create({ProductID: 'gray_tshirt', description: 'A clean gray t-shirt', price: 10}, (err, data) => {
            if (err) throw err
            done()
            }) 
        });

        it('should create one more Product', done => {
            Product.create({ProductID: 'green_tshirt', description: 'A cool green t-shirt', price: 10}, (err, data) => {
            if (err) throw err
            done()
            }) 
        });
    });

    describe('#scan()', () => {
        it('should return all products', done => {
            Product
                .scan()
                .loadAll()
                .exec((err, data) => {
                    if (err) throw err;
                    assert.equal(data.Count, 3, 'Three items in products')                
                    done();
                })
        });
    });

});