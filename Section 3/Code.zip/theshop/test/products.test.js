
const expect = require('chai').expect
const products = require('../service/products')
const createTables = require('../service/model.js').createTables

const fs = require('fs');

process.on('unhandledRejection', e => { throw e; });


describe('Product', function() {

    this.timeout(10000);

    before(done => { 
        createTables(err => {
            if (err) console.error('\tUnable to create tables...')
            else  console.log('\tTables created...')
            done()
        });
    });

    describe('creating products', () => {
        it('should create a Product', done => {
            const event = JSON.parse(fs.readFileSync('./events/product_create_1.json'))
            const context = {} 

            const callback = (err, data) => {
                expect(err).to.be.null
                expect(data.statusCode).to.equal(200, 'Incorrect HTTP status code');
                done();
            } 
            
            expect(event.pathParameters, 'Missing ID in path parameters').not.undefined
            expect(event.pathParameters.id, 'Missing ID in path parameters').not.null

            products.createProduct(event, context, callback)
        });

        it('should return Validation error', done => {
            const event = JSON.parse(fs.readFileSync('./events/product_create_2.json'))
            const context = {} 

            const callback = (err, data) => {
                expect(err).to.be.null
                expect(data.statusCode).to.equal(500, 'Incorrect HTTP status code')

                expect(data.body).to.be.not.null
                const body = JSON.parse(data.body)

                expect(body.error).to.be.not.undefined
                expect(body.error.name).to.equal('ValidationError', 'Wrong error returned')

                done();
            } 
            
            expect(event.pathParameters, 'Missing ID in path parameters').not.undefined
            expect(event.pathParameters.id, 'Missing ID in path parameters').not.null

            products.createProduct(event, context, callback)
        });

        it('should create another Product', done => {
            const event = JSON.parse(fs.readFileSync('./events/product_create_3.json'))
            const context = {} 

            const callback = (err, data) => {
                expect(err).to.be.null
                expect(data.statusCode).to.equal(200, 'Incorrect HTTP status code');
                done();
            } 
            
            expect(event.pathParameters, 'Missing ID in path parameters').not.undefined
            expect(event.pathParameters.id, 'Missing ID in path parameters').not.null

            products.createProduct(event, context, callback)
        });

        it('should create one more Product', done => {
            const event = JSON.parse(fs.readFileSync('./events/product_create_4.json'))
            const context = {} 

            const callback = (err, data) => {
                expect(err).to.be.null
                expect(data.statusCode).to.equal(200, 'Incorrect HTTP status code');
                done();
            } 
            
            expect(event.pathParameters, 'Missing ID in path parameters').not.undefined
            expect(event.pathParameters.id, 'Missing ID in path parameters').not.null

            products.createProduct(event, context, callback)
        });
    });

    describe('querying products', () => {
        it('should find 3 products', done => {
            const event = fs.readFileSync('./events/product_list.json')
            const context = {} 
            const callback = (err, data) => {
                expect(err).to.be.null
                expect(data.statusCode).to.equal(200);

                expect(data.body).to.be.not.null
                const body = JSON.parse(data.body)

                expect(body.Count).to.equal(3);
                done();
            } 
            
            products.listProducts(event, context, callback)
        });
    });

});