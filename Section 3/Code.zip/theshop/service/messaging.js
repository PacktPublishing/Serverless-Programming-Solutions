
const AWS = require('aws-sdk');
const iotData = new AWS.IotData({endpoint: 'YOUR_IOT_ENDPOINT HERE'});
      
exports.handler = (event, context, callback) => {
  const iotParams = {
    payload: JSON.stringify({ message: 'An important update'}),
    topic: `/tshirtshop/${event.receiverId}`
  }
  
  iotData.publish(iotParams, (err, data) => {
    if (err) {
      // handle error here
    }
    callback(null, { success: true })
  })
}