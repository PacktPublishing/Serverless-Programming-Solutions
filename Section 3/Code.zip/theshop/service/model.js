
const Joi = require('joi')
const dynogels = require('dynogels')

dynogels.AWS.config.update({region: process.env.AWS_REGION}); 

if (process.env.AWS_SAM_LOCAL) { // running locally
  console.log('Configuring local DynamoDB...')
  // Set Loopback alias for DOCKER via SAM local
  // ifconfig lo0 alias 172.16.123.1 
  const opts = {endpoint: 'http://172.16.123.1:4569/', region: 'us-east-1'}
  dynogels.dynamoDriver(new dynogels.AWS.DynamoDB(opts))
}

const Customer = dynogels.define('Customer', {
    hashKey: 'CustomerID',
    timestamps: true,
    schema: {
      CustomerID: dynogels.types.uuid(),
      email: Joi.string(),
      name: Joi.string()
    }
});

const Product = dynogels.define('Product', {
    hashKey: 'ProductID',
    schema: {
      ProductID: Joi.string(),
      description: Joi.string(),
      price: Joi.number()
    }
});
  
const ShoppingCart = dynogels.define('Cart', {
    hashKey: 'CartID',
    timestamps: true,
    schema: {
      CartID: dynogels.types.uuid(),
      itemsCount: Joi.number()
    }
});

const ShoppingCartProducts = dynogels.define('CartProducts', {
    hashKey: 'CartID',
    rangeKey: 'ProductID',
    schema: {
      CartID: Joi.string(),  
      ProductID: Joi.string()
    },
    indexes : [{
        name: 'ProductCarts', 
        hashKey: 'ProductID', 
        rangeKey: 'CartID', 
        type: 'global'
    }]
}); 
 
const Order = dynogels.define('Order', {
  hashKey: 'OrderID',
  timestamps: true,
  schema: {
    OrderID: dynogels.types.uuid(),
    CustomerID: Joi.string(),
    address: Joi.object().keys({
      street: Joi.string(),
      postalCode: Joi.string(),
      location: Joi.array(),
      country: Joi.array()
    }),
    products: Joi.array().items(Joi.object().keys({
      ProductID: Joi.string(),
      description: Joi.string(),
      price: Joi.array()
    }))
  }
});

module.exports = {
    Customer: Customer,
    Product: Product,
    Order: Order,
    ShoppingCart: ShoppingCart,
    ShoppingCartProducts: ShoppingCartProducts,
    createTables: dynogels.createTables
}