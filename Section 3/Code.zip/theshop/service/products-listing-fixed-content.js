
exports.listProducts = (event, context, callback) => {

    var items =  [
        {ProductID: 'black_tshirt', description: 'An elegant black t-shirt', price: 10},  
        {ProductID: 'gray_tshirt', description: 'A clean gray t-shirt', price: 10},  
        {ProductID: 'green_tshirt', description: 'A cool green t-shirt', price: 10}
    ];

    var data = {Items: items, Count: 3}

    callback(null, {statusCode: 200, 
        headers: {'Access-Control-Allow-Origin': '*'},
        body: JSON.stringify(data) })
}