const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

module.exports.handler = (event, context, callback) => {
  const body = JSON.parse(event.body);
  const token = body.token.id;
  const amount = body.order.amount;
  const currency = body.order.currency;
  const description = body.order.description;

  return stripe.charges.create({ // Create Stripe charge with token
        amount,
        currency,
        description: description,
        source: token
    })
    .then(charge => { // Success response
      const response = {
        statusCode: 200,
        headers: { 'Access-Control-Allow-Origin': '*'},
        body: JSON.stringify({ message: 'Success!', charge: charge })
      };
      callback(null, response);
    })
    .catch(err => { // Error response
      const response = {
        statusCode: 400,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: err.message })
      };
      callback(null, response);
    })
};