const Order = require('./model').Order


exports.createOrder = (event, context, callback) => {

    const id = event.pathParameters.id || false;

    const item = {ProductID: 'red_tshirt', description: 'A red t-shirt', price: 10}
    item.id = id

    const product = new Product(item)
    const validationResult = Product.validate(product)

    if (validationResult.error) {
        callback(null, { statusCode: 500, 
                        headers: {'Access-Control-Allow-Origin': '*'},
                        body: JSON.stringify({message: `Invalid input: ${validationResult.error.name}`}) 
                })
        return
    }

    callback(null, { statusCode: 200, headers: {'Access-Control-Allow-Origin': '*'}, body: '' })

}

