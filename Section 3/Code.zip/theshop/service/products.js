const Product = require('./model').Product

exports.listProducts = (event, context, response) => {

    Product
        .scan()
        .exec((err, data) =>{
            if (err) {
                response(null, {statusCode: 500, body: `Error retrieving Products: ${err}`})
                return
            }

            const items = data.Items.map(i => i.toJSON());
            const payload = {Items: items, Count: items.length}
        
            response(null, {statusCode: 200, 
                            headers: { 'Access-Control-Allow-Origin': '*' },
                            body: JSON.stringify(payload) })
        });
        
}


exports.createProduct = (event, context, response) => { 

    const id = event.pathParameters.id || false
    const body = JSON.parse(event.body)

    const item = { ProductID:id, 
                    description: body.description || false, 
                    price: body.price || false }

    const product = new Product(item)

    Product.create(item, (err, data) => {
        
        let message = {}

        if (err) {
            message = { error: { name: err.name, details: err.details } } 
        } else {
            message = { success: { message: `CREATED Product<${id}>`} }
        }

        response(null, { statusCode: err ? 500 : 200, 
                         headers: {'Access-Control-Allow-Origin': '*'},
                         body: JSON.stringify(message) })
    })
}


exports.deleteProduct = (event, context, response) => { 

    const id = event.pathParameters.id || false

    Product.destroy({ProductID:id}, (err, data) => {
        
        let message = {}

        if (err) {
            message = { error: { name: err.name, details: err.details } } 
        } else {
            message = { success: { message: `DELETED Product<${id}>`} }
        }

        response(null, { statusCode: err ? 500 : 200, 
                         headers: {'Access-Control-Allow-Origin': '*'},
                         body: JSON.stringify(message) })
    })
}


exports.updateProduct = (event, context, response) => { 

    const id = event.pathParameters.id || false
    const body = JSON.parse(event.body)

    const item = { ProductID:id, 
                    description: body.description || false, 
                    price: body.price || false }

    const product = new Product(item)

    Product.update(item, (err, data) => {
        
        let message = {}

        if (err) {
            message = { error: { name: err.name, details: err.details } } 
        } else {
            message = { success: { message: `Created Product<${id}>`} }
        }

        response(null, { statusCode: err ? 500 : 200, 
                         headers: {'Access-Control-Allow-Origin': '*'},
                         body: JSON.stringify(message) })
    })
}




