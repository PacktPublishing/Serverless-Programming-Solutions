# The t-shirt shop

A serverless t-shit shop.

Follow section 3 videos for more information about the project.