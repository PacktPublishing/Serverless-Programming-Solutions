  AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: '...' // your identity pool id
  })
  
  const client = AWSMqtt.connect({
    WebSocket: window.WebSocket, 
    region: AWS.config.region,
    credentials: AWS.config.credentials,
    endpoint: '<identifier>.iot.<zone>.amazonaws.com',
    clientId: 'mqtt-client-' + '<uniquClientID>'   // client Identity for the MQTT broker, 
                                                   // must be unique per client 

  })
  
  client.on('connect', () => {
    client.subscribe('/tshirtshop')
  })
  
  client.on('message', (topic, message) => {
    // this is where you will handle the messages you send from Lambda
    console.log(topic, message)
  })
  client.on('close', () => {
    // ...
  })
  client.on('offline', () => {
    // ...
  })