const iopipeLib = require('@iopipe/iopipe');
const tracePlugin = require('@iopipe/trace');

const iopipe = iopipeLib({
  token: process.env.IOPIPE_TOKEN,
  plugins: [tracePlugin()]
});

exports.handler = iopipe((event, context, callback) => {
    // Tracing activity1 
    context.iopipe.mark.start('activity1');
    const activity1 = Math.random() > 0.2 ? 1 : 0
    context.iopipe.mark.end('activity1');

    // Tracing activity2
    context.iopipe.mark.start('activity2');
    const activity2 = Math.random() > 0.6 ? 1 : 0
    context.iopipe.mark.end('activity2');

    // Sending a custom metric
    context.iopipe.log('activities-result', activity1 + activity2);
    
    const statusCode = Math.random() > 0.4 ? 200 : 400
    const responsePayload = {
        statusCode: statusCode,
        body: `Success? ${statusCode == 200} -- Visit iopipe dashboard!`
    }

    callback(null, responsePayload)
});
