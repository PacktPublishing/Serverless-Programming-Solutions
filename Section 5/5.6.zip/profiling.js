const iopipeLib = require('iopipe');

const iopipe = iopipeLib({
  token: process.env.IOPIPE_TOKEN,
  plugins: [profilerPlugin({enabled: true})]  // Profiler plugin is DISABLED by default
});

exports.handler = iopipe((event, context, callback) => {

    const statusCode = Math.random() > 0.4 ? 200 : 400

    const responsePayload = {
        statusCode: statusCode,
        body: `Success? ${statusCode == 200} -- Visit iopipe dashboard!`
    }

    callback(null, responsePayload)    
  
});
