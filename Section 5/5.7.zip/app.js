const AWSXRay  = require('aws-xray-sdk');
const {publishOnSNS, writeOnDynamoDB, putObjectOnS3} = require ('./client')

exports.service1 = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    publishOnSNS()
        .then(writeOnDynamoDB)
        .then(() => callback(null, "OK!"))
        .catch(e => callback(e));
};

exports.service2 = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    callback(null, "OK!");
};

exports.service3 = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    putObjectOnS3()
        .then(() => callback(null, "OK!"))
        .catch(e => callback(e))
};

exports.service4 = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    AWSXRay.captureAsyncFunc("## Custom logic:", function(subsegment) {
        try {
            subsegment.addAnnotation("my_annotation", "very_good");
            subsegment.addMetadata("my_metadata", {"a":1, "b":2});

            const done = () => {
                subsegment.close();    
                callback(null, "OK!");
            }

            setTimeout(done, 70);  // Simulate business logic execution
            callback(null, 'OK!');
        } catch(e) {
            callback(e);
        }
    });

};

exports.service5 = (event, context, callback) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    callback(null, "OK!");
};
