
const AWSXRay  = require('aws-xray-sdk');
const AWS      = AWSXRay.captureAWS(require('aws-sdk'));

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();
const s3 = new AWS.S3();

const Promise = require('bluebird');
AWS.config.setPromisesDependency(require('bluebird'));


exports.publishOnSNS = () => {
    console.log('Publishing on SNS...');

    const topic = process.env.MY_TOPIC;
    const content = `Current timestamp: ${Date.now()}`

    const params = { Message: content, TopicArn: topic }
    return sns.publish(params).promise();
};

exports.writeOnDynamoDB = () => {
    console.log('Writing on DB...');

    const min = 100;
    const max = 10000;
    const key = Math.floor(Math.random() * (max - min)) + min; // Random int between min and max
    const content = `Current timestamp: ${Date.now()}`;

    const params = {
        Item: {
            "id": 'K' + key,
            "version": key,
            "message": content
        },
        TableName: process.env.MY_TABLE
    };

    return dynamodb.put(params).promise();
};
    
exports.putObjectOnS3 = (name, body, destBucket) => {
    console.log('Put new object on S3...');

    const params = {
        Body: '',
        Bucket: process.env.MY_BUCKET,
        Key: Date.now() + '.txt'
    }
    return s3.putObject(params).promise();
};